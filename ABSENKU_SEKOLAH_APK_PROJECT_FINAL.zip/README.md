# ABSENKU SEKOLAH Android

APK Android yang membungkus aplikasi Flask ABSENKU SEKOLAH menggunakan Chaquopy.
Build dilakukan oleh GitHub Actions. Database dibuat di penyimpanan internal aplikasi.

Fitur sumber: absensi siswa, guru/tendik, QR, laporan, export Excel, import Dapodik,
logo sekolah, dan footer pembuat.
